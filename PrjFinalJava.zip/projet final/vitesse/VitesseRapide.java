public class VitesseRapide implements VitesseStrategy {
    public int consommerCarburant() {
        return 15;
    }

    public String getNom() {
        return "Rapide";
    }
}

