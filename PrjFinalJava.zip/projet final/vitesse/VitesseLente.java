public class VitesseLente implements VitesseStrategy {
    public int consommerCarburant() {
        return 5;
    }

    public String getNom() {
        return "Lente";
    }
}

