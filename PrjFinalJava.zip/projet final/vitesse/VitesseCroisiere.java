public class VitesseCroisiere implements VitesseStrategy {
    public int consommerCarburant() {
        return 10;
    }

    public String getNom() {
        return "Croisière";
    }
}
