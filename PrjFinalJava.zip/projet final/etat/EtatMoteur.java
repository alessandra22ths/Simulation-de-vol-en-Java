public interface EtatMoteur {
    void demarrer(Appareil appareil);
    void arreter(Appareil appareil);
    String getNom();
}

